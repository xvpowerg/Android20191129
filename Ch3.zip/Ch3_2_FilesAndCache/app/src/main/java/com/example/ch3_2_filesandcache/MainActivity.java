package com.example.ch3_2_filesandcache;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {
           private String fileName = "myFile.txt";
        private void creatFile(View view){
                try(FileOutputStream fOut =
                            openFileOutput(fileName,MODE_PRIVATE);
                    OutputStreamWriter osw = new OutputStreamWriter(fOut)){
                    osw.write("My File.....");
                    Toast.makeText(this,
                            "File Save", Toast.LENGTH_SHORT).show();
                }catch(IOException ex){
                    Log.e("Howard","creatFile:",ex);
                    Toast.makeText(this,
                            "File Save Faill", Toast.LENGTH_SHORT).show();
                }
        }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn = findViewById(R.id.fileBtn);
        Log.d("Howard","btn:"+btn);
        btn.setOnClickListener(this::creatFile);

    }
}
