package com.example.ch3_1_jsonfiletoobject.tools;
import android.util.Log;

import com.example.ch3_1_jsonfiletoobject.bean.Student;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class JsonTools {

    public static void  jsonStringToStudent(String json){
        try {
            JSONObject jsonObject = new JSONObject(json);
           String name =
                   jsonObject.getString("name");
          JSONArray jsonaArray =  jsonObject.getJSONArray("exam");
            for (int i =0; i < jsonaArray.length();i++){
                JSONObject jsObj =  jsonaArray.getJSONObject(i);
                String subject = jsObj.getString("subject");
                int score = jsObj.getInt("score");
                Log.d("Howard","name:"+name+"subject:"+subject+
                        "score:"+score);
            }
        } catch (JSONException e) {
            Log.e("Howard","JSONObject:",e);
        }
    }
    public static void  jsonStringToStudentByGson(String json){
        Gson gson = new GsonBuilder().create();
        Student st =  gson.fromJson(json, Student.class);
        Log.d("Howard","name:"+st.getName());
    }
    public static void  jsonStringToStudentArrayByGson(String json){
        Gson gson = new GsonBuilder().create();
//        ArrayList<LinkedTreeMap>  list =  gson.fromJson(json, ArrayList.class);
//        for (LinkedTreeMap st : list){
//            Log.d("Howard","Student:"+ st.get("name"));
//        }
        Student[] stArray =  gson.fromJson(json,Student[].class);
        for (Student st : stArray){
                Log.d("Howard","st:"+st);
        }
    }


}
