package com.example.ch3_1_jsonfiletoobject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.example.ch3_1_jsonfiletoobject.tools.JsonTools;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    private String getRowData(int resId){
        StringBuilder sb = new StringBuilder();

        try(InputStream is = getResources().openRawResource(resId);
            InputStreamReader inR = new InputStreamReader(is,
                        "UTF-8");){
            char[] buffer = new char[128];
            int index =-1;
            while( (index = inR.read(buffer) ) != -1){
                sb.append(buffer,0,index);
            }
        }catch(IOException ex){
            Log.e("Howard","paserJson:",ex);
        }
        return sb.toString();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String json1 = getRowData(R.raw.student);
        Log.d("Howard","Json:"+json1);
       // JsonTools.jsonStringToStudent(json1);
        //JsonTools.jsonStringToStudentByGson(json1);
        String json2= getRowData(R.raw.student2);
        JsonTools.jsonStringToStudentArrayByGson(json2);

    }
}
