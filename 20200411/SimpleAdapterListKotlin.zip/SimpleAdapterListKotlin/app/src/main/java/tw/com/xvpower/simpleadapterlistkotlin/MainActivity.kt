package tw.com.xvpower.simpleadapterlistkotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.SimpleAdapter
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val list = mutableListOf<Map<String,Any>>()
        val itemNames = arrayOf("產品1","產品2","產品3","產品4","產品5")
        val itemImage = arrayOf(R.drawable.image1,R.drawable.image2,
            R.drawable.image3,R.drawable.image4,R.drawable.image5)
        for (idx in  0 until  itemNames.size ){
            Log.d("Howard","idx:$idx")
            val map1 =  mapOf<String,Any>("itemName" to itemNames[idx],
                "itemImg" to itemImage[idx])
            list.add(map1)
        }

        val simpAdapter = SimpleAdapter(this,list,
                                    R.layout.simple_layout,
                                    arrayOf("itemName","itemImg"),
                                        intArrayOf(R.id.itemNameTxt,
                                            R.id.itemImageView))
        listview.adapter = simpAdapter
        listview.setOnItemClickListener { parent, view, position, id ->
                Log.d("Howard","position:$position")
        }
        //練習 點下去 ListView 的 Item
        //會轉換到下一個頁面 顯示 產品細項
        // 產品細項有 價格 圖片 尺寸:50h 60W
    }
}
