package com.example.ch14_jobscheduler;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.util.Random;
import java.util.concurrent.TimeUnit;


public class MyJobService extends JobService {
    private Handler jobHandler = new Handler(msg -> {
            int n = new Random().nextInt(100);
            Log.d("Howard","jobHandler:"+n);
            jobFinished( (JobParameters) msg.obj,false);
            //回傳true不會繼續往下呼叫
       return true;
    });
    @Override
    public boolean onStartJob(JobParameters params) {
        //回傳true表示 使用其他Thread 做Job 當Job完後自行呼叫jobFinished
        //回傳false表示 工作結束就完成!
        Log.d("Howard","onStartJob!!!");
    new Thread(()->{
            Log.d("Howard","Doing.....");
           try{
               TimeUnit.SECONDS.sleep(5);
           }catch (Exception ex){

           }
        jobHandler.sendMessage(Message.obtain(jobHandler,1,params));

    }).start();

        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        //true 表示Job當在某種條件下可重新啟動Job
        //false  表示Job結束
        Log.d("Howard","onStopJob!!!");
        return false;
    }
}
