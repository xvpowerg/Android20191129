package com.example.ch14_jobscheduler;

import androidx.appcompat.app.AppCompatActivity;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private JobScheduler jobScheduler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       Button startBtn =  findViewById(R.id.startBtn);
       Button cancleBtn = findViewById(R.id.cancelBtn);
       // JobInfo.Builder  的一些方法
        //setRequiresCharging 充電時要做的事情
        // builder.setRequiresCharging();
        //setPersisted 這個Job手機關機後再開機是否繼續
        // builder.setPersisted()
        //JobInfo.NETWORK_TYPE_ANY 一定要有網路的狀態
        //builder.setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
        //如果處於休眠狀態是否執行 預設為Fasle
        //builder.setRequiresDeviceIdle()
        //如果設為true 電池量為低就執行
        //builder.setRequiresBatteryNotLow()
        jobScheduler =
                (JobScheduler) getSystemService(Context.JOB_SCHEDULER_SERVICE);
        startBtn.setOnClickListener(v->{
            ComponentName cpm = new ComponentName(getPackageName(),
                    MyJobService.class.getName());
            JobInfo.Builder builder = new JobInfo.Builder(1,cpm);
           // builder.setPeriodic(15*60*1000);//多久執行一次Job 毫秒
            builder.setMinimumLatency(3000);//工作延遲時間多久
            if (jobScheduler.schedule(builder.build()) <= 0){
                Log.d("Howard","schedule Faill");
            }
        });

        cancleBtn.setOnClickListener(v->{
            jobScheduler.cancel(1);
        });
    }
}
