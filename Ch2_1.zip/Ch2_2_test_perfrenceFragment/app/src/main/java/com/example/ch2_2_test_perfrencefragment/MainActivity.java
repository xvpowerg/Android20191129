package com.example.ch2_2_test_perfrencefragment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
        private  MyPrefrenceFragment mpf;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mpf = new MyPrefrenceFragment();
      FragmentTransaction ft =
              getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.myContent,mpf,"");
        ft.commit();
    }
}
