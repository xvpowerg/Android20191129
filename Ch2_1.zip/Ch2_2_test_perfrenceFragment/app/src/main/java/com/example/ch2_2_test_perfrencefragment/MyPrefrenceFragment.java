package com.example.ch2_2_test_perfrencefragment;

import android.os.Bundle;
import androidx.preference.PreferenceFragmentCompat;

public class MyPrefrenceFragment extends PreferenceFragmentCompat {
    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
            addPreferencesFromResource(R.xml.pef_seting);
    }
}
