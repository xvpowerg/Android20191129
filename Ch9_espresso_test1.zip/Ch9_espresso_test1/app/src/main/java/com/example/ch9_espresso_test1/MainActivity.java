package com.example.ch9_espresso_test1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

      Button btn =  findViewById(R.id.savaBtn);
        btn.setOnClickListener(v->{
         EditText ed =  findViewById(R.id.msgET);
         TextView tv =  findViewById(R.id.msgTxt);
            tv.setText(ed.getText().toString());
        });
    }
}
