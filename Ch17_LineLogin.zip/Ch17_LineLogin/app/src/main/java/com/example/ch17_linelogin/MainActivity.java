package com.example.ch17_linelogin;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.linecorp.linesdk.LoginDelegate;
import com.linecorp.linesdk.LoginListener;
import com.linecorp.linesdk.Scope;
import com.linecorp.linesdk.auth.LineAuthenticationParams;
import com.linecorp.linesdk.auth.LineLoginApi;
import com.linecorp.linesdk.auth.LineLoginResult;
import com.linecorp.linesdk.widget.LoginButton;

import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    private LoginDelegate loginDelegate =LoginDelegate.Factory.create();
    //記得要改成自己的channelId
    private static final String channelId = "";
    //有Bug!!!
    private void defaultLinBtn(){
        LoginButton loginButton =  findViewById(R.id.line_login_btn);
        loginButton.setChannelId(channelId);

        loginButton.setAuthenticationParams(
                new LineAuthenticationParams.Builder().
                        scopes(Arrays.asList(Scope.PROFILE)).build());
        loginButton.setLoginDelegate(loginDelegate);

        loginButton.addLoginListener(new LoginListener() {
            @Override
            public void onLoginSuccess(@NonNull LineLoginResult result) {
                Log.d("Howard","onLoginSuccess...");
            }
            @Override
            public void onLoginFailure(@Nullable LineLoginResult result) {
                Log.d("Howard","onLoginFailure...");
            }
        });
    }

    private void loginClick(View view){
     Intent loginIntent =   LineLoginApi.getLoginIntent(this,channelId,
                new LineAuthenticationParams.Builder().
                scopes(Arrays.asList(Scope.PROFILE)).build());
        startActivityForResult(loginIntent,100);

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         Button btn =    findViewById(R.id.loginLineMyBtn);
         btn.setOnClickListener(this::loginClick);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != 100){
            Log.e("Howard","Error!");
            return;
        }
         LineLoginResult result =  LineLoginApi.getLoginResultFromIntent(data);
        switch(result.getResponseCode()){
            case SUCCESS:
                //AccessToken Line其他API可能會需要
                result.getLineCredential().getAccessToken().getTokenString();
                //使用於 Put Line Message
                String id = result.getLineProfile().getUserId();
                Log.d("Howard","SUCCESS!!!:"+id);
                break;
            case CANCEL:
                Log.d("Howard","CANCEL!!!");
                break;
            default:
                Log.d("Howard","Error!!!");
                break;
        }

    }
}
