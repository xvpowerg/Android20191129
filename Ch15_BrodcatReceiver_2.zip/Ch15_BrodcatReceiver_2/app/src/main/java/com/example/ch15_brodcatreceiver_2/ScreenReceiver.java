package com.example.ch15_brodcatreceiver_2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class ScreenReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
            switch (intent.getAction()){
                // 表示畫面開啟
                case Intent.ACTION_SCREEN_ON:
                    Log.d("Howard","SCREEN_ON....");
                    break;
                // 表示畫面關閉
                case Intent.ACTION_SCREEN_OFF:
                    Log.d("Howard","SCREEN_OFF....");
                    break;
            }
    }
}
