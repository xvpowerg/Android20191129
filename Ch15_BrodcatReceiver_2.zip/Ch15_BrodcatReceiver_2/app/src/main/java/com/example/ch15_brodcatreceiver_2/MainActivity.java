package com.example.ch15_brodcatreceiver_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.CheckBox;

public class MainActivity extends AppCompatActivity {
        ScreenReceiver screenReceiver = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        screenReceiver = new ScreenReceiver();
      CheckBox box =  findViewById(R.id.checkBox);
        box.setOnCheckedChangeListener((cmp,isChecked)->{
            if (isChecked){
                IntentFilter filter = new IntentFilter();
                filter.addAction(Intent.ACTION_SCREEN_ON);
                filter.addAction(Intent.ACTION_SCREEN_OFF);
                registerReceiver(screenReceiver,filter);
            }else if (screenReceiver != null){
                unregisterReceiver(screenReceiver);
            }

        });
    }
}
