package com.example.ch5_1_sqllite.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    private static  final String DB_NAME = "myApp.db";
    private static int version = 1;
    private static String TABLE_NAME = "student";
    private static final String  CREATE_STUDENT_TABLE_SQL =
            "CREATE TABLE "+TABLE_NAME+"(" +
                    "_id INTEGER PRIMARY KEY, " +
                    "name TEXT)";

    public DBHelper(@Nullable Context context) {
        super(context, DB_NAME, null, version);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_STUDENT_TABLE_SQL);
    }

    public boolean insertData(String name){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("namex",name);
        long count =
                db.insert(TABLE_NAME,null,cv);
       return count > 0;
    }

    public boolean  update(String id,String name){
        //因為要更新資料表 所以取的WritableDatabase
       SQLiteDatabase db =  this.getWritableDatabase();
       ContentValues cv = new ContentValues();
        cv.put("name",name); //更新欄位與數值的對應
        ///update 會回傳更新筆數
       int count =  db.update(TABLE_NAME,
                cv,
                "_id=?",//  這是where 條件 _id=?
                new String[]{id}); //這是where 條件對應數值
       return count > 0;
    }
    public boolean delete(String id){
       SQLiteDatabase db =
               getWritableDatabase();
       //DELETE FROM student WHERE _id=2
        int count =
                db.delete(TABLE_NAME,
                "_id = ?",
                new String[]{id});
        return count > 0;
    }

    public List<String> queryData(){
        ArrayList<String> list = new ArrayList<>();
        //因為只有查詢資料表 所以取的ReadableDatabase
        SQLiteDatabase db =   getReadableDatabase();
        Cursor cursor =  db.rawQuery("SELECT * FROM "+TABLE_NAME,
                null);
        while(cursor.moveToNext()){
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            Log.d("Howard","id:"+id+" name:"+name);
            list.add(name);
        }
        return list;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion,
                          int newVersion) {

    }


}
