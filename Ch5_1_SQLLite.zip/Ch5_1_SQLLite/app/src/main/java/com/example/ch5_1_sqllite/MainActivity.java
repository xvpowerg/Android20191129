package com.example.ch5_1_sqllite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.example.ch5_1_sqllite.sqlite.DBHelper;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DBHelper db = new DBHelper(this);

//       boolean b1 =  db.insertData("Vivin");
//        Log.d("Howard","Insert :"+b1);
       db.queryData();


       Log.d("Howard",
               "=================");
       //boolean ub =
        // db.update(String.valueOf(2),"Lindy");
//        Log.d("Howard",
//                "Update:=================:"+ub)
        boolean delb =  db.delete(String.valueOf(2));
        Log.d("Howard",
            "Delete:=================:"+delb);
        db.queryData();

        //Model 模型  資料計算 資料庫等等...:自建立物件
        //View 視圖 圖形介面   跟GUI有關
        //Controller 控制  資料流動 跟頁面轉換 等等...
    }
}
