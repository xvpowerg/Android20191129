package com.example.firebase_photoproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

public class UploadActivity extends AppCompatActivity {
       private ImageView previewImageView ;
       private Uri mainImageURI ;
       private StorageReference storageReference;
       private ProgressBar uploadProgressBar;
       private void openCropImage(){
            CropImage.activity().
                    setGuidelines(CropImageView.Guidelines.ON).
                    setAspectRatio(1,1).
                    start(this);
        }
       private void openPackage(View view){
           if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                if(ContextCompat.checkSelfPermission(this,
                        Manifest.permission.READ_EXTERNAL_STORAGE) !=
                        PackageManager.PERMISSION_GRANTED){

                    Toast.makeText(this, "Permission Denied!",
                            Toast.LENGTH_SHORT).show();
                    ActivityCompat.requestPermissions(this,new String[]{
                            Manifest.permission.READ_EXTERNAL_STORAGE},
                            100);
                }else{
                    //開啟圖片裁切
                    openCropImage();
                }
           }else{
               //開啟圖片裁切
               openCropImage();
           }
       }

       private void upload(View view){
           if (mainImageURI != null)
           {
               uploadProgressBar.setVisibility(View.VISIBLE);
               Log.d("Howard","URI:"+mainImageURI);
               UploadTask uploadTask =  storageReference.child("images.jpg").putFile(mainImageURI);
               uploadTask.addOnCompleteListener(task -> {
                    if (task.isSuccessful()){

                        Toast.makeText(this, "上傳成功", Toast.LENGTH_SHORT).show();
                    }else{
                        String error = task.getException().getMessage();
                        Log.e("Howard","uploadTask error:"+error);
                        Toast.makeText(this, "上傳失敗", Toast.LENGTH_SHORT).show();

                    }
                   uploadProgressBar.setVisibility(View.GONE);
               });
           }

       }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);
        previewImageView = findViewById(R.id.imageView);
        uploadProgressBar = findViewById(R.id.progressBar);
        previewImageView.
                setOnClickListener(this::openPackage);
        storageReference = FirebaseStorage.getInstance().getReference();
       Button upLoadBtn = findViewById(R.id.upload_btn);
        upLoadBtn.setOnClickListener(this::upload);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode,
                permissions, grantResults);
        if (requestCode == 100 &&
                grantResults[0] ==
                        PackageManager.PERMISSION_GRANTED){
            openCropImage();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE){
            CropImage.ActivityResult reault = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK){
                mainImageURI = reault.getUri();
                previewImageView.setImageURI(mainImageURI);
            }else if(resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE){
                Exception error= reault.getError();
                Log.e("Howard","Error:"+error);
            }

        }
    }
}
