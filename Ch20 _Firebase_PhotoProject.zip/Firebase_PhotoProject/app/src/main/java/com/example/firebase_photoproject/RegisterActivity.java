package com.example.firebase_photoproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {
    private EditText emailTxt;
    private EditText pass1Txt;
    private EditText pass2Txt;
    private FirebaseAuth mAuth;

    private void login(View v){
        finish();
    }

    private void onRegisterCompleteListener(Task<AuthResult> task){
            if (task.isSuccessful()){
                    Intent  mainIntent = new Intent(this,
                            MainActivity.class);
                    startActivity(mainIntent);
                    finish();
                    Toast.makeText(this,"Pass!!",
                            Toast.LENGTH_SHORT).show();
            }else{
                String errorMessage =task.getException().getMessage();
                Toast.makeText(this,errorMessage,
                        Toast.LENGTH_SHORT).show();
            }
    }

    private void register(View v){
        String email =  emailTxt.getText().toString();
        String pass1 =  pass1Txt.getText().toString();
        String pass2 =  pass2Txt.getText().toString();

        if (TextUtils.isEmpty(email) ||  TextUtils.isEmpty(pass1) || TextUtils.isEmpty(pass2)){
            Toast.makeText(this,"帳號密碼不可空白",
                    Toast.LENGTH_SHORT).show();
        }else if(pass1.compareTo(pass2) != 0){
            Toast.makeText(this,"密碼不正確",
                    Toast.LENGTH_SHORT).show();
        }else{
            mAuth.createUserWithEmailAndPassword(email,pass1).
                    addOnCompleteListener(this::onRegisterCompleteListener);
        }
    }
    void init(){
        emailTxt = findViewById(R.id.acountTxt);
        pass1Txt = findViewById(R.id.passTxt1);
        pass2Txt = findViewById(R.id.passTxt2);
        Button loginBtn =  findViewById(R.id.login_btn);
        Button regBtn =  findViewById(R.id.reg_btn);
        loginBtn.setOnClickListener(this::login);
        regBtn.setOnClickListener(this::register);
        mAuth = FirebaseAuth.getInstance();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        init();
    }

}
