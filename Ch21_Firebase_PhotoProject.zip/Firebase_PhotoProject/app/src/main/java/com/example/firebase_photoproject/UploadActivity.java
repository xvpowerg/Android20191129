package com.example.firebase_photoproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.util.HashMap;

public class UploadActivity extends AppCompatActivity {
       private ImageView previewImageView ;
       private EditText msgText;
       private Uri mainImageURI ;
       //上傳檔案
       private StorageReference storageReference;
       //寫入資料庫
      private FirebaseFirestore firebaseFirestore;

       private ProgressBar uploadProgressBar;
       private FirebaseAuth firebaseAuth;
       private String userId;
       private void openCropImage(){
            CropImage.activity().
                    setGuidelines(CropImageView.Guidelines.ON).
                    setAspectRatio(1,1).
                    start(this);
        }
       private void openPackage(View view){
           if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                if(ContextCompat.checkSelfPermission(this,
                        Manifest.permission.READ_EXTERNAL_STORAGE) !=
                        PackageManager.PERMISSION_GRANTED){

                    Toast.makeText(this, "Permission Denied!",
                            Toast.LENGTH_SHORT).show();
                    ActivityCompat.requestPermissions(this,new String[]{
                            Manifest.permission.READ_EXTERNAL_STORAGE},
                            100);
                }else{
                    //開啟圖片裁切
                    openCropImage();
                }
           }else{
               //開啟圖片裁切
               openCropImage();
           }
       }


       private void toDataBaseComplete(Task<Void> task){
           if (task.isSuccessful()){
                Log.d("Howard","data base 寫入成功");
           }else{
              String msg =  task.getException().getMessage();
               Log.e("Howard","data base 寫入失敗"+msg);
           }
       }

       private void toDataBase(String imagemMsg,Uri imageURI){
           HashMap<String,String> data = new HashMap();
           data.put("image_msg",imagemMsg);
           data.put("image",imageURI.toString());
           firebaseFirestore.collection("Users").
                   document(userId).collection("images").
                   document(System.currentTimeMillis()+"").
                   set(data).
                   addOnCompleteListener(this::toDataBaseComplete);
       }

       private void upload(View view){
           if (mainImageURI != null)
           {
               uploadProgressBar.setVisibility(View.VISIBLE);
               Log.d("Howard","URI:"+mainImageURI);
        //userId 知道是哪位使用者上傳的圖片
   //取地目前時間轉成毫秒 System.currentTimeMillis() 為了避免 檔案名稱重複
               //上傳圖片
               UploadTask uploadTask =  storageReference.child("upload_images").child(userId).
                       child(System.currentTimeMillis()+".jpg").putFile(mainImageURI);
               uploadTask.addOnCompleteListener(task -> {
                   //task.isSuccessful() 以上傳成功
                    if (task.isSuccessful()){
                        Toast.makeText(this, "上傳成功", Toast.LENGTH_SHORT).show();

                    Task<Uri>  result =
                            task.getResult().getMetadata().
                                    getReference().getDownloadUrl();
                    //當Firebase處理好上傳檔案後 會回呼的方法
                        result.addOnSuccessListener(uri->{
                               String msg =  msgText.getText().toString();
                            toDataBase(msg,uri);
                        });
                    }else{
                        String error = task.getException().getMessage();
                        Log.e("Howard","uploadTask error:"+error);
                        Toast.makeText(this, "上傳失敗", Toast.LENGTH_SHORT).show();
                    }
                   uploadProgressBar.setVisibility(View.GONE);
               });
           }

       }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);
        previewImageView = findViewById(R.id.imageView);
        uploadProgressBar = findViewById(R.id.progressBar);
        previewImageView.
                setOnClickListener(this::openPackage);
        msgText = findViewById(R.id.msg_txt);
        //寫入圖片檔案
        storageReference = FirebaseStorage.getInstance().getReference();
        //寫入資料庫
        firebaseFirestore = FirebaseFirestore.getInstance();

        firebaseAuth = FirebaseAuth.getInstance();
        userId = firebaseAuth.getCurrentUser().getUid();

       Button upLoadBtn = findViewById(R.id.upload_btn);
        upLoadBtn.setOnClickListener(this::upload);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode,
                permissions, grantResults);
        if (requestCode == 100 &&
                grantResults[0] ==
                        PackageManager.PERMISSION_GRANTED){
            openCropImage();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE){
            CropImage.ActivityResult reault = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK){
                mainImageURI = reault.getUri();
                previewImageView.setImageURI(mainImageURI);
            }else if(resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE){
                Exception error= reault.getError();
                Log.e("Howard","Error:"+error);
            }

        }
    }
}
