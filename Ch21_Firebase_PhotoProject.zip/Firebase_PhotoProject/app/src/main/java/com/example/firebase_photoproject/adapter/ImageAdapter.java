package com.example.firebase_photoproject.adapter;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.firebase_photoproject.beans.MyImageInfo;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;


public class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.MyViewHolder> {

    private FirebaseFirestore firebaseFirestore;
    private List<MyImageInfo> dataList = new ArrayList();
    private Context _context;


    private void onReadFireBaseEven(QuerySnapshot snapshot,
                                    FirebaseFirestoreException ex){
        if (ex != null){
            Log.e("Howard","onReadFireBaseEven:",ex);
        }
       List<DocumentSnapshot>  list =  snapshot.getDocuments();
        for (DocumentSnapshot ds : list){
                String imageUri = ds.get("image",String.class);
                String msg = ds.get("image_msg",String.class);
            MyImageInfo minfo = new MyImageInfo(imageUri,msg);
            Log.d("Howard","Test DocumentSnapshot:"+minfo);
            dataList.add(minfo);
            //記得要修正
           // notifyDataSetChanged();
        }

    }
      public ImageAdapter(Context context,String userId){
          _context =context;

          firebaseFirestore = FirebaseFirestore.getInstance();
          firebaseFirestore.collection("Users").
                  document(userId).collection("images").
                  addSnapshotListener(this::onReadFireBaseEven);

      }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private ImageView imageView;
        private TextView nameView;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

}
