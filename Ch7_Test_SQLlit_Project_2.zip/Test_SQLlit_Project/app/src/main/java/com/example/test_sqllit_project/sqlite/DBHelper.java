package com.example.test_sqllit_project.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.test_sqllit_project.bean.Student;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME="student_info.db";
    private static final int DATABASE_VERSION= 1;
    private static final String STUDENT_TABE_NAME = "student";
    private static final String CREATE_STUEDNT_TABLE = "CREATE TABLE "+
            STUDENT_TABE_NAME +
            "(_id INTEGER PRIMARY KEY,"+
            "name TEXT,"+
            "score NUMERIC,"+
            "create_time TIMESTAMP default CURRENT_TIMESTAMP)";
    public DBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public boolean insert(Student st){
       SQLiteDatabase sb = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(Student.DB_NAME_KEY,st.getName());
        cv.put(Student.DB_SCORE_KEY,st.getScore());
       long count = sb.insert(STUDENT_TABE_NAME,null,cv);
        return count > 0;
    }
    public boolean updateById(Student st){
        SQLiteDatabase sb = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(Student.DB_NAME_KEY,st.getName());
        cv.put(Student.DB_SCORE_KEY,st.getScore());
      int count =  sb.update(STUDENT_TABE_NAME,
                cv,
                "_id = ?",
                new String[]{String.valueOf(st.getId())});
      return count > 0;
    }

    public boolean deleteByID(Student st){
         String id = String.valueOf(st.getId()) ;
         SQLiteDatabase db = getWritableDatabase();
    int count = db.delete(STUDENT_TABE_NAME,
            "_id = ?",
            new String[]{id});
        return count > 0;
    }

    public List<Student> queryAll(){
        SQLiteDatabase sb = getReadableDatabase();
        List<Student> list = new ArrayList<>();
        Cursor cursor =
                sb.rawQuery("SELECT * FROM " +STUDENT_TABE_NAME,
                        null);
        while(cursor.moveToNext()){
            long id = cursor.getLong(0);
            String name = cursor.getString(1);
            int score = cursor.getInt(2);
            Student st = new Student(id,name,score);
            list.add(st);
        }
        return list;

    }


    @Override
    public void onCreate(SQLiteDatabase db) {
            db.execSQL(CREATE_STUEDNT_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
