package com.example.ch15_brodcatreceiver_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView msgView = null;
    private MyReveiver2 myReveiver2;
    private BroadcastReceiver myReveiver3 = new BroadcastReceiver(){
        @Override
        public void onReceive(Context context, Intent intent) {
            msgView.setText("myReveiver3......");
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        msgView = findViewById(R.id.msgView);

    //動態註冊1
        myReveiver2 = new MyReveiver2();
        IntentFilter filter = new IntentFilter();
        filter.addAction("test.br.MyReceiver2");
       registerReceiver(myReveiver2,filter);

       Button btn =  findViewById(R.id.sendBro1);
        btn.setOnClickListener((v)->{//靜態註冊使用AndroidManifest 在android8.0無用
            //改用JobScheduler
            Intent i1 = new Intent("test.br.MyReceiver");
            sendBroadcast(i1);
        });

     Button btn2 =    findViewById(R.id.sendBro2);
        btn2.setOnClickListener(v->{
            Intent i2 = new Intent("test.br.MyReceiver2");
            sendBroadcast(i2);
        });

        Button btn3 =    findViewById(R.id.sendBro3);
        btn3.setOnClickListener(v->{
            Intent i3 = new Intent("test.br.MyReceiver3");
            sendBroadcast(i3);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        //動態註冊2
        IntentFilter filter2 = new IntentFilter();
        filter2.addAction("test.br.MyReceiver3");
        registerReceiver(myReveiver3,filter2);
    }

    @Override
    protected void onPause() {
        super.onPause();
         unregisterReceiver(myReveiver2);
        unregisterReceiver(myReveiver3);
    }

}
