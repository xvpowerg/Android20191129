package com.example.ch15_brodcatreceiver_mp3_play;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;

import java.io.File;

public class MainActivity extends AppCompatActivity {
        private MediaPlayer mediaPlayer;
        private Mp3Receiver mp3Receiver =null;

     private void sendAction(String action){
         Intent actionInt = new
                 Intent(action);
         sendBroadcast(actionInt);
     }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       Button btn =  findViewById(R.id.playBtn);
        Button pauseBtn =  findViewById(R.id.pauseBtn);
        Button stopBtn =  findViewById(R.id.stopBtn);

        btn.setOnClickListener(v->sendAction(Mp3Receiver.PLAY_MUSIC_ACTION));
        pauseBtn.setOnClickListener(v->sendAction(Mp3Receiver.PAUSE_MUSIC_ACTION));
        stopBtn.setOnClickListener(v->sendAction(Mp3Receiver.STOP_MUSIC_ACTION));

    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter mp3Filter = new IntentFilter();
        mp3Filter.addAction(Mp3Receiver.PLAY_MUSIC_ACTION);
        mp3Filter.addAction(Mp3Receiver.PAUSE_MUSIC_ACTION);
        mp3Filter.addAction(Mp3Receiver.STOP_MUSIC_ACTION);
        if (mp3Receiver == null){
            mp3Receiver = new Mp3Receiver();
            registerReceiver(mp3Receiver,mp3Filter);
        }
    }
}
