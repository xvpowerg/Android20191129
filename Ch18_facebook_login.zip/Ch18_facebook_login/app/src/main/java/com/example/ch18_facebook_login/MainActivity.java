package com.example.ch18_facebook_login;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.Profile;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;

import java.security.MessageDigest;

public class MainActivity extends AppCompatActivity {
    private CallbackManager callbackManager;

    // 產生SHA編碼
        private void toSHA(){
        PackageInfo info;

        try{
            info = getPackageManager().
                    getPackageInfo("com.example.ch18_facebook_login",
                            PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures){
                MessageDigest md;
                md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                String keyResult = new String(Base64.encode(md.digest(),0));
                Log.d("Howard",keyResult);
            }
        }catch(Exception ex){
            Log.e("Howard",ex.toString());
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //toSHA();
       LoginButton loginButton =
                findViewById(R.id.login_button);
        loginButton.setReadPermissions("email");
        callbackManager = CallbackManager.Factory.create();
        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                Log.d("Howard","onSuccess!!");
            }
            @Override
            public void onCancel() {
                Log.d("Howard","onCancel!!");
            }
            @Override
            public void onError(FacebookException error) {
                Log.e("Howard","FacebookException!!"+error);
            }
        });

        if (Profile.getCurrentProfile() != null){
            Profile p = Profile.getCurrentProfile();
            //取出FB的大頭照
            Uri userPhoto = p.getProfilePictureUri(300,300);
            String id = p.getId();
           String name =  p.getName();
           Log.d("Howard","name:"+name);

        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        callbackManager.onActivityResult(requestCode,resultCode,data);
        super.onActivityResult(requestCode, resultCode, data);

    }
}
