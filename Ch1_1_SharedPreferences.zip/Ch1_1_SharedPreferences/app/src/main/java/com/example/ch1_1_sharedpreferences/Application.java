package com.example.ch1_1_sharedpreferences;

public class Application {
    public static final String CHECK_BOX_KEY="checkBox";
}
