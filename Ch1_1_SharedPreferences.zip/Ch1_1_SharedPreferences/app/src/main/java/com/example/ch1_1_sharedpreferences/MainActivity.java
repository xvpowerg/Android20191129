package com.example.ch1_1_sharedpreferences;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
        private SharedPreferences sp;

        private int[] checkBoxId = {
                R.id.checkBox,
                R.id.checkBox2,
                R.id.checkBox3,
                R.id.checkBox4,
                R.id.checkBox5};
        private CheckBox[] checkBoxArray = new CheckBox[5];


        private void initCheckBox(){
                for (int i = 0; i <checkBoxId.length ;i++){
                    checkBoxArray[i] =  findViewById(checkBoxId[i]);
                    boolean isChecked = sp.getBoolean(Application.CHECK_BOX_KEY+i,false);
                    checkBoxArray[i].setChecked(isChecked);
                }
        }
    private void saveData(View view) {
        EditText nameText =  findViewById(R.id.nameText);
        EditText passText =  findViewById(R.id.passText);
       SharedPreferences.Editor editor =  sp.edit();
        String name = nameText.getText().toString();
        String pass = passText.getText().toString();
        editor.putString("name",name);
        editor.putString("pass",pass);

        for (int i =0; i < checkBoxArray.length;i++){
           boolean checked = checkBoxArray[i].isChecked();
            editor.putBoolean(
                    Application.CHECK_BOX_KEY+i,
                    checked);
        }


        editor.apply();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sp = getSharedPreferences("test_login",
                Context.MODE_PRIVATE);
        initCheckBox();



        String name = sp.getString("name","");
        String pass = sp.getString("pass","");
        Log.d("Howard","name:"+name+" pass:"+pass);
        Button saveBtn =  findViewById(R.id.saveBtn);
        saveBtn.setOnClickListener(this::saveData);

    }
}
