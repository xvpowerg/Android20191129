package com.example.ch11_1;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyCursorAdapter extends RecyclerView.Adapter<MyCursorAdapter.MyViewHolder>  {
        private Context mContext;
        private Cursor cursor;

    public MyCursorAdapter(Context mContext, Cursor cursor) {
        this.mContext = mContext;
        this.cursor = cursor;
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView idTxt;
        public TextView nameTxt;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            idTxt = itemView.findViewById(R.id.idTxt);
            nameTxt = itemView.findViewById(R.id.nameTxt);
        }
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view =  LayoutInflater.from(mContext).inflate(R.layout.re_view_layout,
                parent,false);
        MyViewHolder myViewHolder = new MyViewHolder(view);

        myViewHolder.idTxt = view.findViewById(R.id.idTxt);
        myViewHolder.nameTxt = view.findViewById(R.id.nameTxt);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
            if (cursor.moveToPosition(position)){
                holder.idTxt.setText(cursor.getString(0));
                holder.nameTxt.setText(cursor.getString(1));
            }
    }

    @Override
    public int getItemCount() {
        return cursor.getCount();
    }


}
