package com.example.ch11_1;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;

public class MyProvider extends ContentProvider {
    private SQLiteDatabase db = null;
    private String table = "coffee_list";
    final String DB_NAME = "coffee_5000.db";
    final String DB_PATH = File.separator+"data"+
            Environment.getDataDirectory().getAbsolutePath()+
            File.separator+
            "com.example.ch11_1" +
            File.separator+DB_NAME;
    @Override
    public boolean onCreate() {
        Log.d("Howard","onCreate:~MyProvider....");
         db = SQLiteDatabase.openOrCreateDatabase(DB_PATH,null);
        return true;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection,
                        @Nullable String selection, @Nullable String[] selectionArgs,
                        @Nullable String sortOrder) {
        Log.d("Howard","onCreate:~query....");
        return db.query(table,projection,selection,selectionArgs,
                null,null,sortOrder);
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues values) {
        return null;
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }
}
