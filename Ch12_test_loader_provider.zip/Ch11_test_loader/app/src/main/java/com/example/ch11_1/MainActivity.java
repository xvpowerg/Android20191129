package com.example.ch11_1;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.concurrent.Executors;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.widget.Button;

public class MainActivity extends AppCompatActivity
        implements LoaderManager.LoaderCallbacks<Cursor> {
    private LoaderManager loaderManager;
    RecyclerView rcView = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //LoaderManager.getInstance(this) 的 this 指 AppCompatActivity
        loaderManager = LoaderManager.getInstance(this);
        //LoaderManager.getInstance(this) 的 this
                    // 指 LoaderManager.LoaderCallbacks<Cursor>
        loaderManager.initLoader(1,null,this);
        rcView =  findViewById(R.id.rcView);
        rcView.setLayoutManager(new LinearLayoutManager(this));
    }

    @NonNull
    @Override

    public Loader<Cursor> onCreateLoader(int id, @Nullable Bundle args) {
        //建立一組Loader
        //載入資料 會在新的Thread

        final String DB_NAME = "coffee_5000.db";
        final String DB_PATH = File.separator+"data"+
                Environment.getDataDirectory().getAbsolutePath()+
                File.separator+
                getApplicationContext().getPackageName() +
                File.separator+DB_NAME;
        SQLiteDatabase db = openDatabase(DB_PATH);
        MyCursorLoader myCursorLoader =
                new MyCursorLoader(this,db);
        return myCursorLoader;
    }

    private SQLiteDatabase openDatabase(String dbfile){
            if ( new File(dbfile).exists() == false ){

              try(InputStream is = getResources().openRawResource(R.raw.coffee_5000);
               FileOutputStream fos = new FileOutputStream(dbfile);){
                        byte[] buffer = new byte[1024];
                        int count = 0;
                        while( (count = is.read(buffer)) > 0){
                                fos.write(buffer,0,count);
                        }
              }catch(Exception ex){
                  Log.e("Howard","Exception:"+ex);
              }
            }
            SQLiteDatabase db =
                    SQLiteDatabase.openOrCreateDatabase(dbfile,null);
        return db;
    }

    @Override
    public void onLoadFinished(@NonNull Loader<Cursor> loader, Cursor data) {
                Log.d("Howard","Loader size:"+data.getCount());
               MyCursorAdapter adapter = new MyCursorAdapter(this,data);
                rcView.setAdapter(adapter);
    }
    @Override
    public void onLoaderReset(@NonNull Loader<Cursor> loader) {

    }
}
