package com.example.ch2_3_json;

import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {


    private void testAndroidJsonObj(String st){
        try{
            JSONObject jsonObject = new JSONObject(st);
            String title = jsonObject.getString("title");
            int price = jsonObject.getInt("price");
            Log.d("Howard",title+":"+price);
        }catch (JSONException ex){
            Log.e("Howard","JSONException:",ex);
        }
    }

    private void testAndroidJsonArray(String st){

        try {
            JSONArray jsonArray = new JSONArray(st);
          int v1 =   jsonArray.getInt(0);
          String v2 =   jsonArray.getString(1);
          String v3 =   jsonArray.getString(2);
          Log.d("Howard",v1+":"+v2+":"+v3);

            for (int i = 0; i < jsonArray.length();i++){

                String value =   jsonArray.getString(i);
                Log.d("Howard","Loop:"+value);
            }
        } catch (JSONException e) {
            Log.e("Howard","JSONException",e);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String jsonObj = "{\"title\":\" PS5 \"," +
                        "\"price\":300}";
        testAndroidJsonObj(jsonObj);
        String jsonArray2 = "[10,\"Vivin\",50]";
        testAndroidJsonArray(jsonArray2);
    }
}
