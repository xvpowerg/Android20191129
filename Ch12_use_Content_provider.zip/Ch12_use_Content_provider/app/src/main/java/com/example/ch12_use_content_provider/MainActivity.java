package com.example.ch12_use_content_provider;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.CursorAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

public class MainActivity extends AppCompatActivity {
    private Uri myUri = Uri.parse("content://com.example.ch11_1.MyProvider");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
     Cursor cursor =
             getContentResolver().query(myUri,new String[] {"_id","title","price"},
                null,null,null);
        Log.d("Howard","cursor:"+cursor.getCount());
        ListView list = findViewById(R.id.list_view);
        SimpleCursorAdapter adpater = new SimpleCursorAdapter(this,
                R.layout.list_item_layout,
                cursor,
                new String[]{"_id","title","price"},
                new int[]{R.id.idTxt,R.id.titleTxt,R.id.priceTxt},
                CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        list.setAdapter(adpater);


    }
}
