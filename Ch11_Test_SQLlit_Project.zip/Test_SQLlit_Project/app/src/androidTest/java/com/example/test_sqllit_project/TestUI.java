package com.example.test_sqllit_project;


import androidx.recyclerview.widget.RecyclerView;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import org.hamcrest.Matcher;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import java.util.Random;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.clearText;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.longClick;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.contrib.RecyclerViewActions.actionOnItem;
import static androidx.test.espresso.matcher.ViewMatchers.hasDescendant;
import static androidx.test.espresso.matcher.ViewMatchers.hasSibling;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static com.example.test_sqllit_project.matcher.Util.hasItem;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.core.AllOf.allOf;

@RunWith(AndroidJUnit4.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestUI {
    static String testName = "";
    static String testScore = "";
    static String updateTestName = "";
    static String updateTestScore = "";
    static  Matcher m1;
    static  Matcher m2;

    //BeforeClass 最先執行的標記
    @BeforeClass
    public static void init(){
        Random ran = new Random();
        testName = "Ken:"+ran.nextInt(50000);
        testScore = ran.nextInt(50000)+"";

        updateTestName = "Iris:"+ran.nextInt(50000);
        updateTestScore = ran.nextInt(50000)+"";

        m1 = allOf(withText(testScore),hasSibling(withText(testName)));
        m2 = allOf(withText(updateTestScore),hasSibling(withText(updateTestName)));
    }
     @Rule
    public ActivityTestRule<MainActivity> activityRule =
             new  ActivityTestRule<>(MainActivity.class);
     @Test
    public void aTestInsert(){
         onView(withId(R.id.fab)).perform(click());
         onView(withId(R.id.nameET)).perform(typeText(testName));
         onView(withId(R.id.scoreET)).perform(typeText(testScore));
         onView(withId(android.R.id.button1)).perform(click());

//         onView(m1).check(matches(isDisplayed()));
         //因為要指定matches的是 RecyclerView內的Item所以要加上hasDescendant
         onView(withId(R.id.rcView)).check( matches(hasItem(hasDescendant(m1))));
     }
    @Test
    public void bTestUpdata(){
        //onView(m1).perform(longClick());
        //RecyclerViewActions
        //actionOnItem 必須 import RecyclerViewActions
        onView(withId(R.id.rcView)).
                perform(actionOnItem(hasDescendant(m1),
                                  longClick()));
        onView(withText("Update")).perform(click());
        //檢查是否有帶入舊值
        onView(withId(R.id.nameET)).check(matches(withText(testName)));
        onView(withId(R.id.scoreET)).check(matches(withText(testScore)));
        onView(withId(R.id.nameET)).perform(clearText());
        onView(withId(R.id.scoreET)).perform(clearText());
        onView(withId(R.id.nameET)).perform(typeText(updateTestName));
        onView(withId(R.id.scoreET)).perform(typeText(updateTestScore));

        onView(withId(android.R.id.button1)).perform(click());
        onView(withId(R.id.rcView)).check( matches(hasItem(hasDescendant(m2))));
    }

    @Test
    public void cTestDelete(){
//        onView(withId(R.id.rcView)).
//                perform(actionOnItem(hasDescendant(m2),
//                        longClick()));
//        onView(withText("Delete")).perform(click());
//        onView(withId(R.id.rcView)).check( matches(not(hasItem(hasDescendant(m2))) ));
    }

}
