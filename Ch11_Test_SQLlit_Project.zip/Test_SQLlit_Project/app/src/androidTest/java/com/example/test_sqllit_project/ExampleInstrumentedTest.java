package com.example.test_sqllit_project;

import android.content.Context;
import android.util.Log;

import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.test_sqllit_project.bean.Student;
import com.example.test_sqllit_project.sqlite.DBHelper;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import static org.junit.Assert.*;

/**
 * Instrumented test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class ExampleInstrumentedTest {
    static Student tmpSt  = null;
    //所有標記@Test 方法都會執行
    //執行 順序由上至下

    @Test
    public void insertContext() {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        DBHelper db = new DBHelper(appContext);
        Student st1 = new Student(0,"Ken",78);
        //如果為左邊參數為False 會拋出錯誤訊息 INSERT ERROR!
        //ssertTrue("INSERT ERROR!",db.insert(st1));
    }

    @Test
    public void queryContext() {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        DBHelper db = new DBHelper(appContext);
        List<Student> list = db.queryAll();
        tmpSt = list.get(list.size() - 1);
        Log.d("Howard","query student:"+tmpSt);
        //如果為左邊參數為0 會拋出錯誤訊息
        assertNotEquals(0,list.size());
    }
    @Test
    public void updateContext() {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        DBHelper db = new DBHelper(appContext);
        Log.d("Howard","update student:"+tmpSt);
        assertTrue("Update ERROR!",db.updateById(tmpSt));
    }
    @Test
    public void deleteContext() {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        DBHelper db = new DBHelper(appContext);
        Log.d("Howard","delete student:"+tmpSt);
        assertTrue("Delete ERROR!",db.deleteByID(tmpSt));

    }


}
