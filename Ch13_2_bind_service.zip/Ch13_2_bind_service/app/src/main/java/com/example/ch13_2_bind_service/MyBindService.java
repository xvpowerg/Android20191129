package com.example.ch13_2_bind_service;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class MyBindService extends Service {
    MyBinder myBinder  = new MyBinder();
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.d("Howard","onBind....");
        return myBinder;
    }
    public class MyBinder extends Binder {
           public  TextView msgTxtView;
           public  int count = 0;

        public void startCountBackwards(){
                    count--;
        }

    }



    @Override
    public boolean onUnbind(Intent intent) {
        Log.d("Howard","onUnbind....");
        return super.onUnbind(intent);
    }

    @Override
    public void onRebind(Intent intent) {
        Log.d("Howard","onRebind...");
        super.onRebind(intent);
    }
}
