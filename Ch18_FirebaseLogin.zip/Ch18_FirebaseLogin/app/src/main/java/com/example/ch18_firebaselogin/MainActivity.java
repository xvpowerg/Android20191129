package com.example.ch18_firebaselogin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private  EditText accountETxt;
    private  EditText passETxt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //取的FirebaseAuth 物件
        mAuth = FirebaseAuth.getInstance();
        accountETxt =
                findViewById(R.id.account_txt);
        passETxt =findViewById(R.id.pass_txt);
        //註冊
    Button registBtn = findViewById(R.id.register_btn);
        registBtn.setOnClickListener(v->{
          String email =  accountETxt.getText().toString();
            String pass =  passETxt.getText().toString();
            mAuth.createUserWithEmailAndPassword(email,pass).
                    addOnCompleteListener((Task<AuthResult> task)->{
                                if (task.isSuccessful()){
                                    Log.d("Howard",
                                            "Success!");
                                }else{
                                    Log.w("Howard",
                                            "Faill!"+task.getException());
                                }
                        });

        });
        //登入
        Button loginBtn = findViewById(R.id.login_btn);
        loginBtn.setOnClickListener(v->{
            String email =  accountETxt.getText().toString();
            String pass =  passETxt.getText().toString();
            mAuth.signInWithEmailAndPassword(email,pass).
                    addOnCompleteListener(task->{

                        if(task.isSuccessful()) {
                            Log.d("Howard","Login isSuccessful!!");
                        }else{
                            Log.e("Howard",
                                    "Login Faill!!"+task.getException());
                        }

                    });

        });

    }
}
