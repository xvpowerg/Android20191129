package com.example.ch13_2_bind_service;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.TimeUnit;

public class MyBindService extends Service {
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            myBinder.msgTxtView.setText(msg.arg1+"");
            Log.d("Howard","msg:"+msg.arg1);
        }
    };
    MyBinder myBinder  = new MyBinder();
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.d("Howard","onBind....");
        return myBinder;
    }
     static interface CompleteAction{
            public void action();
    }
    public class MyBinder extends Binder {

          public  boolean runThread = true;
           public  TextView msgTxtView;
           public  int count = 0;
           public CompleteAction completeAction;
        public void complete(){
            if (completeAction != null)
                completeAction.action();
        }
        public void startCountBackwards(){
           Thread th1 = new Thread(()->{
              int tmpCount =  count;
              for (int i=tmpCount;runThread&&i>=0;i--){
                  Message msg =  Message.
                          obtain(handler,1,i,0);
                  handler.sendMessage(msg);
                  try{
                      TimeUnit.SECONDS.sleep(1);
                  }catch(Exception ex){}
              }
               complete();
           });
            th1.start();
        }

    }



    @Override
    public boolean onUnbind(Intent intent) {
        Log.d("Howard","onUnbind....");
        return super.onUnbind(intent);
    }

    @Override
    public void onRebind(Intent intent) {
        Log.d("Howard","onRebind...");
        super.onRebind(intent);
    }
}
