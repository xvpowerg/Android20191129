package com.example.ch13_2_bind_service;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
        private ServiceConnection serviceConnection;
        private MyBindService.MyBinder myBinder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        serviceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                Log.d("Howard","serviceConnection....");
                myBinder =(MyBindService.MyBinder)service;
                myBinder.runThread = true;
                myBinder.msgTxtView = findViewById(R.id.msgTxtView);
                myBinder.completeAction =
                        ()->{Log.d("Howard","完成!!!");};
            }
            @Override
            public void onServiceDisconnected(ComponentName name) {
                Log.d("Howard","serviceConnection....");
                myBinder = null;
            }
        };
        Button bindBtn = findViewById(R.id.bindBtn);
        //BIND_AUTO_CREATE 如果 Service 不存在會自動建立
        bindBtn.setOnClickListener((v)->{
            Log.d("Howard","bindService....");
            Intent bindIntent = new Intent(this,MyBindService.class);
            bindService(bindIntent,serviceConnection, Context.BIND_AUTO_CREATE);
        } );
        Button setBtn =   findViewById(R.id.setCountBtn);
        setBtn.setOnClickListener(v->{
            EditText et =  findViewById(R.id.countET);
            String countStr = et.getText().toString();
            myBinder.count = Integer.parseInt(countStr);
        });

        Button invokeBtn =   findViewById(R.id.invokeBtn);
        invokeBtn.setOnClickListener(v->{
            myBinder.startCountBackwards();
        });
//1 按下Stop希望Thread停止
//2 倒數計時完成後我想做某件事
       Button stopBtn = findViewById(R.id.stopBtn);
        stopBtn.setOnClickListener(v->{
            myBinder.runThread = false;
            unbindService(serviceConnection);
            Log.d("Howard",
                    "unbindService....");
        });
    }
}
