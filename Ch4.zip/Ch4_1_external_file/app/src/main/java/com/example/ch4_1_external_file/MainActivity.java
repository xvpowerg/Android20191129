package com.example.ch4_1_external_file;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {
            private String fileName = "exterFile.txt";

            private void readFile(File file) {
                StringBuilder sb = new StringBuilder();
                try (FileReader fr = new FileReader(file)) {
                    char[] buffer = new char[128];
                    int index = -1;
                    while ((index = fr.read(buffer)) != -1) {
                        sb.append(buffer, 0, index);
                    }
                    TextView tv = findViewById(R.id.msgView);
                    tv.setText(sb.toString());
                } catch (IOException ex) {
                    Log.e("Howard", "readFile:" + ex);
                }
            }

        private void createFile(View view){
            File filesDir =  getExternalFilesDir(null);
            Log.d("Howard","filesDir:"+filesDir);
            File file = new File(filesDir,fileName);
            try(FileOutputStream fOut = new FileOutputStream(file);
                OutputStreamWriter osw = new OutputStreamWriter(fOut)){
                osw.write("（中央社記者曾婷瑄巴黎6日專電）" +
                        "法國歷史性全國大罷工5日登場，為抗議法國總統馬克" +
                        "宏提出的退休制度改革，全國各職業工會集結80多萬人上街" +
                        "抗議，巴黎日常生活大癱瘓。馬克宏深信，" +
                        "改革是需要的，但他會為了改革做出些許讓步。");
            }catch (IOException ex){
                Log.e("Howard","createFile",ex);
            }

            readFile(file);

        }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn =   findViewById(R.id.testFileBtn);
        btn.setOnClickListener(this::createFile);

        String state =   Environment.getExternalStorageState();
        Log.d("Howard","StorageState:"+isExternal());
    }

    boolean isExternal(){
        String state =  Environment.getExternalStorageState();
        return state != null && state.equals(Environment.MEDIA_MOUNTED);
    }
}
