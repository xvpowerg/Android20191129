package com.example.ch3_2_filesandcache;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class MainActivity extends AppCompatActivity {
    private String fileName = "myFile.txt";
         private void readFile(File file){

            Log.d("Howard","File:"+file.getAbsolutePath());
             File txtFile = new File(file.getAbsolutePath(),fileName);
             StringBuilder sb = new StringBuilder();
                try(FileReader fr = new FileReader(txtFile);){
                        char[] buffer = new char[128];
                        int index = -1;
                        while( (index = fr.read(buffer))!=-1 ){
                            sb.append(buffer,0,index);
                        }
                }catch(IOException ex){
                Log.e("Howard","IOException:"+ex);
                }
             Log.d("Howard","Values:"+sb.toString());

         }
        private void creatFile(View view){
                try(FileOutputStream fOut =
                            openFileOutput(fileName,MODE_PRIVATE);
                    OutputStreamWriter osw = new OutputStreamWriter(fOut)){
                    osw.write("在合作活動期間，位於晴空塔 450 公尺高的天望回廊將以" +
                            "《Final Fantasy VII 重製版》世界觀為主題進行原創裝飾。" +
                            "位於晴空塔 350 公尺高的天望平台會在玻璃窗上設置巨大螢幕的" +
                            "「晴空塔環形劇院」，播放只有在現場才能看到的活動原創內容。" +
                            "現場還會販售合作活動限定的原創周邊商品以及原創設計的咖啡飲品。");
                    Toast.makeText(this,
                            "File Save", Toast.LENGTH_SHORT).show();
                }catch(IOException ex){
                    Log.e("Howard","creatFile:",ex);
                    Toast.makeText(this,
                            "File Save Faill", Toast.LENGTH_SHORT).show();
                }
            readFile(getFilesDir());
        }

        @RequiresApi(api = Build.VERSION_CODES.O)
        private void createCache(View view){
             File cacheDir =   getCacheDir();
            Log.d("Howard","createCache Dir Path:"+
                    cacheDir.getAbsolutePath());
             File file = new File(cacheDir.getAbsolutePath(),fileName);
            try(FileOutputStream fOut = new FileOutputStream(file);
              OutputStreamWriter osw = new  OutputStreamWriter(fOut);) {
                osw.write("Cache File save!!!!");

            }catch(IOException ex){
                Log.e("Howard","createCache IOException:"+ex);
            }
            readFile(getCacheDir());
            //NIO2
//            Path path =  cacheDir.toPath();
//            try{
//                Files.write(path,
//                        "Cache File Save!!!".getBytes());
//            }catch (IOException e){
//                Log.e("Howard","");
//            }



        }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn = findViewById(R.id.fileBtn);
        Log.d("Howard","btn:"+btn);
        btn.setOnClickListener(this::creatFile);
        Button btn2 = findViewById(R.id.button2);
        btn2.setOnClickListener(this::createCache);
    }
}
