package com.example.ch5_1_sqllite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import com.example.ch5_1_sqllite.sqlite.DBHelper;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DBHelper db = new DBHelper(this);
//       boolean b1 =  db.insertData("Vivin");
//        Log.d("Howard","Insert :"+b1);
        ListView listView = findViewById(R.id.listView);
        List<String> dataList =  db.queryData();
        for (int i =1;i<=50000;i++){
            dataList.add("Test:"+i);
        }
        listView.setAdapter(
                new MyAdapter(this,dataList));

        //Model 模型  資料計算 資料庫等等...:自建立物件
        //View 視圖 圖形介面   跟GUI有關
        //Controller 控制  資料流動 跟頁面轉換 等等...
    }
}
