package com.example.ch5_1_sqllite;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class MyAdapter extends BaseAdapter {
    private List<String> list=null;
    private Context context = null;
    private class MyViewHolder{
        TextView idTxt;
        TextView nameTxt;
    }
    public MyAdapter(Context context, List<String> list){
            this.context = context;
            this.list = list;
    }
    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Log.d("Howard","getView:"+position);
        TextView idTxt = null;
        TextView nameTxt = null;
        if (convertView == null){
            convertView =  LayoutInflater.from(context).inflate(R.layout.list_layout,null);
            idTxt =  convertView.findViewById(R.id.itemId);
            nameTxt =  convertView.findViewById(R.id.itemeName);
            MyViewHolder myvh = new MyViewHolder();
            myvh.idTxt = idTxt;
            myvh.nameTxt = nameTxt;
            convertView.setTag(myvh);
        }else{
            MyViewHolder vh = (MyViewHolder)  convertView.getTag();
            idTxt =  vh.idTxt;
            nameTxt = vh.nameTxt;

        }

        String name = list.get(position);
        idTxt.setText(String.valueOf(position));
        nameTxt.setText(name);

        return convertView;
    }
}
