package com.example.ch6_1_test_recycler_view;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RcAdapter extends  RecyclerView.Adapter<RcAdapter.MyViewHolder> {
    private List<String> list;
    private Context context;

    class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView textView;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

    public RcAdapter(  Context context,List<String> list){
            this.list = list;
            this.context = context;
    }
    //1 先建立MyViewHolder
    //2 再去實作Adapter 抽象方法
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
         View view =  LayoutInflater.from(context).inflate(R.layout.rcview_layout,null);
         //RecyclerView 每個Item第一次建立時呼叫此區塊 用來存放 View 與 View相關元件
         MyViewHolder mvh = new MyViewHolder(view);
         mvh.textView = view.findViewById(R.id.nameTxt);
        return mvh;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        // 當Item建立後時呼叫此區塊 用來取得 View 與 View相關元件 做設定
        holder.textView.setText(list.get(position));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }




}
