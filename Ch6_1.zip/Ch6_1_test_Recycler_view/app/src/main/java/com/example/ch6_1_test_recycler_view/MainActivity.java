package com.example.ch6_1_test_recycler_view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
      RecyclerView rcv =  findViewById(R.id.rcView);
        //setLayoutManager 一定要加
        rcv.setLayoutManager(new GridLayoutManager(this,5));
        ArrayList<String> list = new ArrayList<>();
        for (int i =1;i<=50000;i++){
            list.add("A"+i);
        }
        RcAdapter rca = new RcAdapter(this,list);
        rcv.setAdapter(rca);
    }
}
