package com.example.ch13_service_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       Button startBtn =  findViewById(R.id.startBtn);
       Button stopBtn =  findViewById(R.id.stonBtn);

        startBtn.setOnClickListener((v)->{
            Log.d("Howard","startBtn!!!");
            Intent myIntent = new Intent(this,MyService.class);
            myIntent.putExtra(MyService.Service_Key,
                    MyService.PLAY);
            startService(myIntent);
        });
        stopBtn.setOnClickListener((v)->{
            Intent myIntent =
                    new Intent(this,
                            MyService.class);
            stopService(myIntent);

        });


    }
}
