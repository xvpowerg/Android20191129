package com.example.ch13_service_1;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.Date;
import java.util.concurrent.TimeUnit;

public class MyService extends Service {
    public static final String Service_Key = "action";
    public static final int PLAY =1;
    public static final int STOP =2;
    private Handler handler = new Handler();

    private Runnable showTime= new Runnable() {
        @Override
        public void run() {
            Log.d("howard",new Date().toString());
            Log.d("howard",Thread.currentThread().getName());
            handler.postDelayed(this,1000);
        }
    };

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    @Override
    public void onCreate(){
           super.onCreate();
        Log.d("Howard","onCreate!!");
        Log.d("howard","onCreate: "+Thread.currentThread().getName());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        //Service.START_STICKY Service 被Android 系統移除後
             // 會自動啟動Service 但是 Intent 為 null
        //Service.START_REDELIVER_INTENT Service 被Android 系統移除後
        // 會自動啟動Service 但是 Intent 不為 null
       //  Service.START_NOT_STICKY Service 被Android 系統移除後
        //              不會自動啟動Service

        handler.post(showTime);
        Log.d("Howard","onStartCommand....");
//        try{
//            TimeUnit.SECONDS.sleep(10);
//        }catch(InterruptedException ex){
//        }

      int action =
              intent.getIntExtra(Service_Key,-1);
        Log.d("Howard","onStartCommand....:"+action);
        return Service.START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("Howard","onDestroy....");
        handler.removeCallbacks(showTime);
    }
}
