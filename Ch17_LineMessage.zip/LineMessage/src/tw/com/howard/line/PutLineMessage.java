package tw.com.howard.line;

import java.util.concurrent.ExecutionException;

import com.linecorp.bot.client.LineMessagingClient;
import com.linecorp.bot.model.PushMessage;
import com.linecorp.bot.model.message.TextMessage;
import com.linecorp.bot.model.response.BotApiResponse;

public class PutLineMessage {
//記得換成自己的Message token
final static String token = "";
//記得自己的userId 注意不是Line帳號的userId是 ch17_linelogin 產生的UserId
final static String userId = "";
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		// TODO Auto-generated method stub
			LineMessagingClient client = LineMessagingClient.
					builder(token).build();
			TextMessage msg = new TextMessage("Hello!!");
			PushMessage pushMessage =
					new PushMessage(userId,msg);
			BotApiResponse botApi = null;
			botApi = client.pushMessage(pushMessage).get();
			
	}

}
