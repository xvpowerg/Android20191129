package com.example.test_sqllit_project;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;

import com.example.test_sqllit_project.adapter.StudentAdapter;
import com.example.test_sqllit_project.bean.Student;
import com.example.test_sqllit_project.sqlite.DBHelper;
import com.example.test_sqllit_project.verify.EmptyVerify;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private DBHelper _dbHelper;
    private StudentAdapter _stAdapter;
    private RecyclerView _rcView;
    private void initRecyclerView(){
        List<Student> list =   _dbHelper.queryAll();
        _stAdapter = new StudentAdapter(this,list);
        //幫
        DividerItemDecoration itemDecoration =
                new DividerItemDecoration(this,
                        DividerItemDecoration.VERTICAL);
        _rcView.addItemDecoration(itemDecoration);

        _rcView.setLayoutManager(new LinearLayoutManager(this));
        _rcView.setAdapter(_stAdapter);
    }


    private void alertBtnLinstener(DialogInterface dialog,int which) {
        Dialog dialogObj = (Dialog) dialog;
        EditText nameET = dialogObj.findViewById(R.id.nameET);
        EditText scoreET = dialogObj.findViewById(R.id.scoreET);
        Log.d("Howard", nameET + ":" + scoreET);
        String name = nameET.getText().toString();
        String score = scoreET.getText().toString();

        boolean test1 = EmptyVerify.testEmpty(name,
                () -> Toast.makeText(this, "姓名不可空白",
                            Toast.LENGTH_SHORT).show());
        boolean test2 = EmptyVerify.testEmpty(score, () ->
                Toast.makeText(this, "成績不可空白", Toast.LENGTH_SHORT).show());

        if (test1 || test2) {
            return;
        }

            Student st1 = new Student(name, score);
            DBHelper.InsertInfo info = _dbHelper.insert(st1);
            if (info.isPass()) {
                st1.setId(info.getId());
                _stAdapter.add(st1);
            }

    }
    private void showInerDialog(View view){

      View dialogView =  getLayoutInflater().inflate(R.layout.dialog_layout,null);
        AlertDialog.Builder bu = new AlertDialog.Builder(this).
                setView(dialogView).setNegativeButton("取消",null).
                setPositiveButton("確定",this::alertBtnLinstener).setCancelable(false);
        //setPositiveButton andorid.R.id.button1
        bu.create().show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        _dbHelper = new DBHelper(this);
        _rcView = findViewById(R.id.rcView);
        FloatingActionButton fab = findViewById(R.id.fab);
       fab.setOnClickListener(this::showInerDialog);
    }

    @Override
    protected void onResume() {
        super.onResume();
        initRecyclerView();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
