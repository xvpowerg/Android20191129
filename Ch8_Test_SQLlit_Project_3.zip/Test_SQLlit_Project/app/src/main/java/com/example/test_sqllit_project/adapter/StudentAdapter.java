package com.example.test_sqllit_project.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.test_sqllit_project.R;
import com.example.test_sqllit_project.bean.Student;

import java.util.List;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.MyViewHolder> {
    private Context context;
    private List<Student> list;
    public StudentAdapter(Context context, List<Student> list){
                this.context = context;
                this.list = list;
    }

    public void add(Student st){
        list.add(st);
        notifyItemInserted(list.size() - 1);
        //notifyDataSetChanged();
    }

    public Student get(int postion){
        Student st = list.get(postion);
        //Student newSt = new Student(st.getId(),st.getName(),st.getScore());
        //clone 確保Student不會被修改
        //只能透過 Adpater的方式修改
        return st.clone();
    }

    public void update(Student st,int index){
        list.set(index,st);
        notifyItemChanged(index);//通知RecyclerView 變動畫面
    }

    public void delete(Student st,int index){
        list.remove(index);
        notifyItemRemoved(index);
    }

    class MyViewHolder extends RecyclerView.ViewHolder{
        TextView nameText;
        TextView scoreText;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view =  LayoutInflater.from(context).inflate(R.layout.list_view_layout,parent,
                false);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        myViewHolder.nameText = view.findViewById(R.id.nameText);
        myViewHolder.scoreText = view.findViewById(R.id.scoreText);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
         Student tmpSt =  list.get(position);
        holder.nameText.setText(tmpSt.getName());
        holder.scoreText.setText(String.valueOf(tmpSt.getScore()));
    }
    @Override
    public int getItemCount() {
        return list.size();
    }

}
