package com.example.ch16_youttube_api;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;
import com.google.android.youtube.player.YouTubeThumbnailLoader;
import com.google.android.youtube.player.YouTubeThumbnailView;

public class MainActivity extends YouTubeBaseActivity {
    public static final String API_KEY = "AIzaSyC8QjUxLTsUx6u0_-IKd8P-CIPlJqxlp84";
    private String vid = "4M_AiGA5wpA";
    private YouTubePlayerView youTubePlayerView;
    private YouTubePlayer _youTubePlayer;
    private YouTubeThumbnailView youTubeThumbnailView;
    private class YoutubInitiListener implements YouTubePlayer.OnInitializedListener {
        @Override
        public void onInitializationSuccess(YouTubePlayer.Provider provider,
                                            YouTubePlayer youTubePlayer,
                                            boolean wasRestored) {
            //wasRestored 為false就是表示 想重新定義影片
            //wasRestored 為true就是表示 想恢復撥放位置 並不重新載入新影片
            Log.d("Howard","Success....");
            if (!wasRestored)
                youTubePlayer.cueVideo(vid);
            _youTubePlayer = youTubePlayer;
        }

        @Override
        public void onInitializationFailure(YouTubePlayer.Provider provider,
                                            YouTubeInitializationResult youTubeInitializationResult) {
            Log.d("Howard","Failure....");

        }
    }


    private class YouTubeThumbnailInitiListener implements YouTubeThumbnailView.OnInitializedListener{

        @Override
        public void onInitializationSuccess(YouTubeThumbnailView youTubeThumbnailView,
                                            YouTubeThumbnailLoader youTubeThumbnailLoader) {
        Log.d("Howard","YouTubeThumbnail Success");
            youTubeThumbnailLoader.setVideo(vid);
        }

        @Override
        public void onInitializationFailure(YouTubeThumbnailView youTubeThumbnailView,
                                            YouTubeInitializationResult youTubeInitializationResult) {
            Log.d("Howard","YouTubeThumbnail Failure");
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //如果出現java.lang.SecurityException  可能是 AndroidManifest 沒加上
        //<uses-permission android:name="android.permission.INTERNET"></uses-permission>
        //縮圖
        youTubeThumbnailView = findViewById(R.id.youtube_thumbnai);
        youTubeThumbnailView.initialize(API_KEY,new YouTubeThumbnailInitiListener());

        youTubeThumbnailView.setOnClickListener(v->{
                String msg = "Play";
            if (_youTubePlayer.isPlaying()){
                _youTubePlayer.pause();
                msg ="Pause";
            }else{
                _youTubePlayer.play();
            }
            Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
        });
        //播放Youtube的畫面
        youTubePlayerView = findViewById(R.id.youtube_view);
        YoutubInitiListener listener = new  YoutubInitiListener();
        youTubePlayerView.initialize(API_KEY,listener);
    }
}
