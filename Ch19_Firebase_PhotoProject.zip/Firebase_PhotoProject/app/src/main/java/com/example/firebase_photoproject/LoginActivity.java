package com.example.firebase_photoproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {
        private EditText loginEmailText;
        private EditText loginPassText;
        private Button loginBtn;
        private Button regBtn;
        private FirebaseAuth mAuth;

        private void completeListener(Task<AuthResult> task){
                if (task.isSuccessful()){
                    toMainPage();
                }else{
                    String errorMessage = "登入失敗";
                    Log.d("Howard","Login Exception:"+ task.getException());
                    Toast.makeText(this,errorMessage,Toast.LENGTH_LONG).show();
                }
        }
      private void loginAction(View view){
         String email =  loginEmailText.getText().toString();
         String pass = loginPassText.getText().toString();
            if (!TextUtils.isEmpty(email) && !TextUtils.isEmpty(pass) ){
                mAuth.signInWithEmailAndPassword(email,pass).
                        addOnCompleteListener(this::completeListener);
            }
          //登入成功
              // 轉到ManActivity Page
          //登入失敗
             //當下頁面顯示錯誤訊息
      }

      private void toMainPage(){
          Intent mainIntent = new Intent(this,MainActivity.class);
          startActivity(mainIntent);
          finish();
      }

     private void init(){
         mAuth = FirebaseAuth.getInstance();
         loginEmailText = findViewById(R.id.acountTxt);
         loginPassText = findViewById(R.id.passTxt);
         loginBtn = findViewById(R.id.login_btn);
         regBtn = findViewById(R.id.reg_btn);
     }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        init();
        regBtn.setOnClickListener(v->{
            Log.d("Howard","註冊頁面");
        });
        loginBtn.setOnClickListener(this::loginAction);
    }

    @Override
    protected void onStart() {
        super.onStart();
        //如果目前正在登入狀態  就轉到MainActivity
        if (mAuth.getCurrentUser() != null){
             // 轉到ManActivity Page
            toMainPage();
        }

    }
}
