package com.example.ch22_widget;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.os.Handler;
import android.util.Log;
import android.widget.RemoteViews;

import java.util.Calendar;
import java.util.concurrent.TimeUnit;

public class TestAppWidget extends AppWidgetProvider {
    private Handler handler = new Handler();
    private AppWidgetManager manager;
    private RemoteViews remoteViews = null;
    private ComponentName thisWidget;

    private void resetTime(){
        while(true){
            handler.post(()->updateTime());
             try{
                TimeUnit.SECONDS.sleep(1); }
              catch(InterruptedException ex){ }
        }
    }

    private void updateTime(){
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR);
        int minute = calendar.get(Calendar.MINUTE);
        int second = calendar.get(Calendar.SECOND);
        String time = String.format("%02d:%02d:%02d",hour,minute,second);
        remoteViews.setTextViewText(R.id.widget_text,time);
        //呼叫updateAppWidget才會更新Widget
        manager.updateAppWidget(thisWidget,remoteViews);
    }

    @Override
    public void onUpdate(Context context,
                         AppWidgetManager appWidgetManager,
                         int[] appWidgetIds) {
        Log.d("Howard","onUpdate..");
        thisWidget = new ComponentName(context,TestAppWidget.class);
        manager =AppWidgetManager.getInstance(context);
        remoteViews = new RemoteViews(context.getPackageName(),R.layout.widget_layout);
        Thread th1 = new Thread(this::resetTime);
        th1.start();
    }
}
