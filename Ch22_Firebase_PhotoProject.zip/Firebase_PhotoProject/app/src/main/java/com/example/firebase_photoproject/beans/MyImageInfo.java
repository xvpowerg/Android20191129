package com.example.firebase_photoproject.beans;

import android.net.Uri;

import io.grpc.okhttp.internal.Util;

public class MyImageInfo {
    private Uri imageUri;
    private String message;

    public MyImageInfo(Uri imageUri, String message) {
        this.imageUri = imageUri;
        this.message = message;
    }

    public MyImageInfo(String imageUri, String message) {
        this(Uri.parse(imageUri),message);
    }

    public Uri getImageUri() {
        return imageUri;
    }
    public void setImageUri(Uri imageUri) {
        this.imageUri = imageUri;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    @Override
    public String toString() {
        return "MyImageInfo{" +
                "imageUri=" + imageUri +
                ", message='" + message + '\'' +
                '}';
    }
}
